# Practical No. 6
# Title: To create a program in python to handle string operations.
# Problem Statement: Write a python program that accepts a string from user
# and perform following string operations-
# (i) Calculate length of string
# (ii) String reversal
# (iii) Equality check of two strings
# (iv) Check palindrome
# (v) Check substring

s = input("Enter a string: ")

while(1):
    print("1.Length\n2.Reverse\n3.Equality of two strings\n4.Check Palindrome\n5.Check substring")
    choice = int(input("Enter your choice: "))

    if choice == 1:
        print("Length of string is", len(s))

    elif choice == 2:
        print("Reverse string is", s[::-1])

    elif choice == 3:
        s2 = input("Enter string to compare: ")
        if s == s2:
            print("Equal")
        else:
            print("Not equal")

    elif choice == 4:
        if s == s[::-1]:
            print("String is Palindrome")
        else:
            print("String is not Palindrome")

    elif choice == 5:
        s2 = input("Enter substring to check: ")
        if s2 in s:
            print("Sub string is present")
        else:
            print("Substring is Absent")

    else:
        print("invalid choice")

    cont = input("\nDo you want to continue? (yes/no): ")
    if cont.lower() != 'yes':
        break
