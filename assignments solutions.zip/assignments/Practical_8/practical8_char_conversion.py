# Practical No. 8
# Title: Character Conversion UPPER to lower and lower to UPPER case.
# Problem Statement: To copy contents of one file to other.
# While copying:
# a) all full stops are to be replaced with commas
# b) lower case are to be replaced with upper case
# c) upper case are to be replaced with lower case

# First, create a sample input.txt file to demonstrate
with open("input.txt", "w") as f:
    f.write("Hello World. This is a Test File.\n")
    f.write("Python Programming is Fun. Let us Learn it.\n")
    f.write("File Handling is an Important Concept. Practice it Daily.\n")

print("input.txt created successfully.")

# Method 1: Using file handling to read and write
# Using 'r' mode for reading, 'w' mode for writing
try:
    fin = open("input.txt", 'r')   # file opening in read mode
    fout = open("output.txt", 'w') # file is created

    for line in fin:
        line = line.swapcase()          # Replace lower case with upper and upper with lower
        line = line.replace(".", ",")   # Replace full stops with ,
        fout.write(line)

    fin.close()
    fout.close()

    print("File copied with character conversion successfully!")
    print("\n--- Output File Content ---")
    with open("output.txt", "r") as f:
        print(f.read())

except:
    print("File error occured")
