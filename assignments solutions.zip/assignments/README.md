# Programming and Problem Solving - Practical Assignments
## Department of First Year Engineering

---

## Practical No. 6 - String Operations
**File:** `Practical_6/practical6_string_operations.py`

**Title:** To create a program in python to handle string operations.

**Operations performed:**
1. Calculate length of string
2. String reversal
3. Equality check of two strings
4. Check palindrome
5. Check substring

**How to run:**
```
python practical6_string_operations.py
```

---

## Practical No. 7 - File writelines() Method
**File:** `Practical_7/practical7_writelines.py`

**Title:** Program to write a file using the writelines() method.

**Description:** Creates a text file, appends a list of strings using writelines(), then reads and prints the file content.

**How to run:**
```
python practical7_writelines.py
```
> Note: This will create `demofile3.txt` in the same directory.

---

## Practical No. 8 - Character Conversion
**File:** `Practical_8/practical8_char_conversion.py`

**Title:** Character Conversion UPPER to lower and lower to UPPER case.

**Description:** Copies content from `input.txt` to `output.txt` with:
- All full stops (.) replaced with commas (,)
- Lowercase letters converted to UPPERCASE
- UPPERCASE letters converted to lowercase

**How to run:**
```
python practical8_char_conversion.py
```
> Note: This will create `input.txt` (sample) and `output.txt` automatically.

---

## Sample Test Cases

### Practical 6:
| Input | Choice | Expected Output |
|-------|--------|-----------------|
| Madam | 4 | String is Palindrome |
| Python | 2 | Reverse string is nohtyP |

### Practical 8:
| Input (input.txt) | Expected Output (output.txt) |
|---|---|
| Hello World. | hELLO wORLD, |
| Python Programming. | pYTHON pROGRAMMING, |
