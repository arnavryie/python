# Practical No. 7
# Title: Program to write a file using the writelines() method.
# Problem Statement: To accept data from file, create text file in file directory.
# Add list of text to append the file.
# Theory: The writelines() method writes the items of a list to the file.
# Syntax: file.writelines(list)

# Step 1: Create/write initial content to the file
f = open("demofile3.txt", "w")
f.writelines(["Hello World!\n", "Welcome to Python.\n", "File handling is easy.\n"])
f.close()

print("Initial file written successfully.")

# Step 2: Append new lines to the file using writelines() in "a" mode
f = open("demofile3.txt", "a")
f.writelines(["\nSee you soon!", "\nOver and out."])
f.close()

print("Lines appended successfully.")

# Step 3: Open and read the file after appending
f = open("demofile3.txt", "r")
print("\n--- File Content ---")
print(f.read())
f.close()
