class EMPLOYEE:
    total_employees = 0
    male_count = 0
    female_count = 0
    employees_with_high_salary = []
    employees_asst_manager = []

    def __init__(self, name, designation, gender, date_of_joining, salary):
        self.name = name
        self.designation = designation
        self.gender = gender
        self.date_of_joining = date_of_joining
        self.salary = salary

        EMPLOYEE.total_employees += 1

        if gender.lower() == 'male':
            EMPLOYEE.male_count += 1
        elif gender.lower() == 'female':
            EMPLOYEE.female_count += 1

        if salary > 10000:
            EMPLOYEE.employees_with_high_salary.append(self)

        if designation.lower() == "asst manager":
            EMPLOYEE.employees_asst_manager.append(self)

    @staticmethod
    def get_total_employees():
        return EMPLOYEE.total_employees

    @staticmethod
    def get_male_count():
        return EMPLOYEE.male_count

    @staticmethod
    def get_female_count():
        return EMPLOYEE.female_count

    @staticmethod
    def get_employees_with_high_salary():
        return [emp.name for emp in EMPLOYEE.employees_with_high_salary]

    @staticmethod
    def get_employees_asst_manager():
        return [emp.name for emp in EMPLOYEE.employees_asst_manager]


emp1 = EMPLOYEE("John Doe", "Manager", "Male", "01-01-2020", 15000)
emp2 = EMPLOYEE("Jane Smith", "Asst Manager", "Female", "15-03-2021", 8000)
emp3 = EMPLOYEE("Alice Brown", "Asst Manager", "Female", "10-07-2019", 12000)
emp4 = EMPLOYEE("Bob White", "Developer", "Male", "12-05-2018", 9500)

print(f"Total Employees: {EMPLOYEE.get_total_employees()}")
print(f"Male Employees: {EMPLOYEE.get_male_count()}")
print(f"Female Employees: {EMPLOYEE.get_female_count()}")
print(f"Employees with salary more than 10,000: {EMPLOYEE.get_employees_with_high_salary()}")
print(f"Employees with designation 'Asst Manager': {EMPLOYEE.get_employees_asst_manager()}")
