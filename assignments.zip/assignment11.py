import math

k_e = 8.99 * 10**9

def calculate_force(q1, q2, r):
    try:
        force = k_e * abs(q1 * q2) / r**2
        return force
    except ZeroDivisionError:
        return "Distance cannot be zero."

def calculate_electric_field(q, r):
    try:
        electric_field = k_e * abs(q) / r**2
        return electric_field
    except ZeroDivisionError:
        return "Distance cannot be zero."

def calculate_potential(q, r):
    try:
        potential = k_e * q / r
        return potential
    except ZeroDivisionError:
        return "Distance cannot be zero."

def main():
    print("Electrostatics Calculator")
    print("Choose what to calculate:")
    print("1. Force between two charges")
    print("2. Electric field due to a charge")
    print("3. Electric potential due to a charge")

    choice = input("Enter the number of the calculation you want to perform: ")

    if choice == '1':
        q1 = float(input("Enter the value of charge 1 (in Coulombs): "))
        q2 = float(input("Enter the value of charge 2 (in Coulombs): "))
        r = float(input("Enter the distance between the charges (in meters): "))
        force = calculate_force(q1, q2, r)
        print(f"The force between the charges is: {force} Newtons")

    elif choice == '2':
        q = float(input("Enter the value of charge (in Coulombs): "))
        r = float(input("Enter the distance from the charge (in meters): "))
        electric_field = calculate_electric_field(q, r)
        print(f"The electric field at this point is: {electric_field} N/C")

    elif choice == '3':
        q = float(input("Enter the value of charge (in Coulombs): "))
        r = float(input("Enter the distance from the charge (in meters): "))
        potential = calculate_potential(q, r)
        print(f"The electric potential at this point is: {potential} Volts")

    else:
        print("Invalid choice. Please choose 1, 2, or 3.")

if __name__ == "__main__":
    main()
