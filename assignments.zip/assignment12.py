def calculate_reactions(length, load1, position1, load2=None, position2=None):
    if load2 is None:
        reaction_A = reaction_B = load1 / 2
    else:
        reaction_B = (load1 * (length / 2) + load2 * position2) / length
        reaction_A = load1 + load2 - reaction_B

    return reaction_A, reaction_B

def main():
    length = 4

    load1 = 100
    position1 = 2

    reaction_A, reaction_B = calculate_reactions(length, load1, position1)
    print(f"Case 1: Load of {load1} kN at the center of the beam")
    print(f"Reaction at A = {reaction_A} kN")
    print(f"Reaction at B = {reaction_B} kN")
    print()

    load2 = 50
    position2 = 1

    reaction_A, reaction_B = calculate_reactions(length, load2, position2, load2, position2)
    print(f"Case 2: Load of {load2} kN at 1 meter from A")
    print(f"Reaction at A = {reaction_A} kN")
    print(f"Reaction at B = {reaction_B} kN")

if __name__ == "__main__":
    main()
