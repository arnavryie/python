weight = 12
mass = 4.893

g = weight / mass

print(f"Weight = {weight} N")
print(f"Mass = {mass} kg")
print(f"Gravity on the planet = {g:.4f} m/s^2")
